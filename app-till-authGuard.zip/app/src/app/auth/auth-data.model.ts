export interface AuthData {
    email: string;
    password: string;
    username: string;
    userphonenumber: number;
    useraddress: string;
    usertype: string;
}