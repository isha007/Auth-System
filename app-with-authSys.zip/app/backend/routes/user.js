const express = require('express');
const bcrypt = require('bcrypt');

const router = express.Router();

const User = require('../models/user');

router.post("/register", (req, res, next) => {
    bcrypt.hash(req.body.password, 10)
    .then(hash => {
        const user = new User({
            email: req.body.email,
            password: hash,
            username: req.body.username,
            userphonenumber: req.body.userphonenumber,
            useraddress: req.body.useraddress,
            usertype: req.body.usertype
    });
    user.save()
        .then(result => {
            res.status(201).json({
                message: "User created successfully",
                result: result
            });
        })
        .catch(err => {
            res.status(500).json({
                error: err
            });
        });
    });
});


module.exports = router;