export interface AuthData {
    id: string;
    email: string;
    password: string;
    username: string;
    userphonenumber: number;
    useraddress: string;
    usertype: string;
}